# Bootstrap 3 Grid widget for CKEditor 4
Bootstrap grid widget for CKEditor >= 4.3
It depends on ckeditor widget plugin. http://ckeditor.com/addon/widget
It only works properly with bootstrap 3 enabled websites since otherwise it is just some html.
Demo video https://www.youtube.com/watch?v=Up7egPLxfdI

I do reccomend to use http://ckeditor.com/builder for non development purposes.

##Other Bootstrap 3 software for CKEditor 4

Bootstrap 3 Quicktable https://github.com/kaido24/btquicktable

Bootstrap 3 grid https://github.com/kaido24/bt_table
