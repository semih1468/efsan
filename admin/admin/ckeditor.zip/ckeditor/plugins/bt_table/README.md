# Bootstrap 3 table plugin for CKEditor 4

This plugin is built on top original table plugin. This is really 80% same code with lots of modifications some simplifications.

It will just replace some original table plugin functionality and adds Bootstrap 3 options.

##Installation

Add this plugin to CKEditor folder/plugins

config.extraPlugins = 'language';

You may read more about manual installation at http://docs.ckeditor.com/#!/guide/dev_plugins

## Other Bootstrap 3 software for CKEditor 4
Bootstrap 3 Quicktable https://github.com/kaido24/btquicktable

Bootstrap 3 grid https://github.com/kaido24/btgrid
